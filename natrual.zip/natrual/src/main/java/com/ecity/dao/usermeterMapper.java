package com.ecity.dao;

import com.ecity.entity.usermeter;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;

public interface usermeterMapper {
    @Insert({
        "insert into T_BS_USERMETER (BUSISN, BUSITYPE, ",
        "NODESN, NODETYPE, ",
        "USERID, BARCODE, ",
        "RESID, SUPPLYPOINTID, ",
        "RESTYPE, FACTORYID, ",
        "MODELID, PRESS, ",
        "CALIBER, RANGE, ",
        "RATE, FIXDIRECT, METERDIRECT, ",
        "ISBILL, ISBRANCH, ISBLIND, ",
        "ISSEAL, ISBUY, OILUNIT, ",
        "OILCYCLE, CHECKCYCLE, ",
        "OILNEXT, CHECKNEXT, ",
        "FIXDATE, REMOVEDATE, ",
        "METERBOX, POSINUM, ",
        "FIXMODE, METERPOSI, ",
        "CARDDIRECT, ENV, ISSAFETY, ",
        "TEMPPRESSFACTOR, ADJUSTFACTOR, ",
        "IMGCODE, SEALCODE, ",
        "MODIFIERCODE, BASEFACTOR, ",
        "STATE, VER, NEWFLAG, ",
        "AREAPART, OPTRCODE, ",
        "OPTDATE, REMARK, ",
        "STAND)",
        "values (#{busisn,jdbcType=VARCHAR}, #{busitype,jdbcType=VARCHAR}, ",
        "#{nodesn,jdbcType=VARCHAR}, #{nodetype,jdbcType=VARCHAR}, ",
        "#{userid,jdbcType=VARCHAR}, #{barcode,jdbcType=VARCHAR}, ",
        "#{resid,jdbcType=VARCHAR}, #{supplypointid,jdbcType=VARCHAR}, ",
        "#{restype,jdbcType=VARCHAR}, #{factoryid,jdbcType=VARCHAR}, ",
        "#{modelid,jdbcType=VARCHAR}, #{press,jdbcType=VARCHAR}, ",
        "#{caliber,jdbcType=VARCHAR}, #{range,jdbcType=DECIMAL}, ",
        "#{rate,jdbcType=DECIMAL}, #{fixdirect,jdbcType=CHAR}, #{meterdirect,jdbcType=CHAR}, ",
        "#{isbill,jdbcType=CHAR}, #{isbranch,jdbcType=CHAR}, #{isblind,jdbcType=CHAR}, ",
        "#{isseal,jdbcType=CHAR}, #{isbuy,jdbcType=CHAR}, #{oilunit,jdbcType=CHAR}, ",
        "#{oilcycle,jdbcType=VARCHAR}, #{checkcycle,jdbcType=VARCHAR}, ",
        "#{oilnext,jdbcType=TIMESTAMP}, #{checknext,jdbcType=TIMESTAMP}, ",
        "#{fixdate,jdbcType=TIMESTAMP}, #{removedate,jdbcType=TIMESTAMP}, ",
        "#{meterbox,jdbcType=VARCHAR}, #{posinum,jdbcType=VARCHAR}, ",
        "#{fixmode,jdbcType=CHAR}, #{meterposi,jdbcType=VARCHAR}, ",
        "#{carddirect,jdbcType=CHAR}, #{env,jdbcType=VARCHAR}, #{issafety,jdbcType=CHAR}, ",
        "#{temppressfactor,jdbcType=DECIMAL}, #{adjustfactor,jdbcType=DECIMAL}, ",
        "#{imgcode,jdbcType=VARCHAR}, #{sealcode,jdbcType=VARCHAR}, ",
        "#{modifiercode,jdbcType=VARCHAR}, #{basefactor,jdbcType=DECIMAL}, ",
        "#{state,jdbcType=CHAR}, #{ver,jdbcType=DECIMAL}, #{newflag,jdbcType=CHAR}, ",
        "#{areapart,jdbcType=CHAR}, #{optrcode,jdbcType=VARCHAR}, ",
        "#{optdate,jdbcType=TIMESTAMP}, #{remark,jdbcType=VARCHAR}, ",
        "#{stand,jdbcType=VARCHAR})"
    })
    int insert(usermeter record);

    @InsertProvider(type=usermeterSqlProvider.class, method="insertSelective")
    int insertSelective(usermeter record);
}