package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;

import com.ecity.entity.contactinfo;

public class contactinfoSqlProvider {

    public String insertSelective(contactinfo record) {
        BEGIN();
        INSERT_INTO("T_AR_CONTACTINFO");
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getBusitype() != null) {
            VALUES("BUSITYPE", "#{busitype,jdbcType=VARCHAR}");
        }
        
        if (record.getNodesn() != null) {
            VALUES("NODESN", "#{nodesn,jdbcType=VARCHAR}");
        }
        
        if (record.getNodetype() != null) {
            VALUES("NODETYPE", "#{nodetype,jdbcType=VARCHAR}");
        }
        
        if (record.getContactid() != null) {
            VALUES("CONTACTID", "#{contactid,jdbcType=VARCHAR}");
        }
        
        if (record.getOwntype() != null) {
            VALUES("OWNTYPE", "#{owntype,jdbcType=CHAR}");
        }
        
        if (record.getOwnid() != null) {
            VALUES("OWNID", "#{ownid,jdbcType=VARCHAR}");
        }
        
        if (record.getType() != null) {
            VALUES("TYPE", "#{type,jdbcType=CHAR}");
        }
        
        if (record.getName() != null) {
            VALUES("NAME", "#{name,jdbcType=VARCHAR}");
        }
        
        if (record.getPosition() != null) {
            VALUES("POSITION", "#{position,jdbcType=VARCHAR}");
        }
        
        if (record.getDeptname() != null) {
            VALUES("DEPTNAME", "#{deptname,jdbcType=VARCHAR}");
        }
        
        if (record.getContactphone() != null) {
            VALUES("CONTACTPHONE", "#{contactphone,jdbcType=VARCHAR}");
        }
        
        if (record.getMobile() != null) {
            VALUES("MOBILE", "#{mobile,jdbcType=CHAR}");
        }
        
        if (record.getContactaddr() != null) {
            VALUES("CONTACTADDR", "#{contactaddr,jdbcType=VARCHAR}");
        }
        
        if (record.getZipcode() != null) {
            VALUES("ZIPCODE", "#{zipcode,jdbcType=CHAR}");
        }
        
        if (record.getBirthday() != null) {
            VALUES("BIRTHDAY", "#{birthday,jdbcType=CHAR}");
        }
        
        if (record.getFax() != null) {
            VALUES("FAX", "#{fax,jdbcType=VARCHAR}");
        }
        
        if (record.getEmail() != null) {
            VALUES("EMAIL", "#{email,jdbcType=VARCHAR}");
        }
        
        if (record.getVer() != null) {
            VALUES("VER", "#{ver,jdbcType=DECIMAL}");
        }
        
        if (record.getNewflag() != null) {
            VALUES("NEWFLAG", "#{newflag,jdbcType=CHAR}");
        }
        
        if (record.getAreapart() != null) {
            VALUES("AREAPART", "#{areapart,jdbcType=CHAR}");
        }
        
        if (record.getOptrcode() != null) {
            VALUES("OPTRCODE", "#{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            VALUES("OPTDATE", "#{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            VALUES("REMARK", "#{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            VALUES("STAND", "#{stand,jdbcType=VARCHAR}");
        }
        
        return SQL();
    }
}