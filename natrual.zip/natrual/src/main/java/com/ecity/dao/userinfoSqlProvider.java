package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SET;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.UPDATE;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;
import static org.apache.ibatis.jdbc.SqlBuilder.WHERE;

import com.ecity.entity.userinfo;

public class userinfoSqlProvider {

    public String insertSelective(userinfo record) {
        BEGIN();
        INSERT_INTO("T_BS_USERINFO");
        
        if (record.getUserid() != null) {
            VALUES("USERID", "#{userid,jdbcType=VARCHAR}");
        }
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getBusitype() != null) {
            VALUES("BUSITYPE", "#{busitype,jdbcType=VARCHAR}");
        }
        
        if (record.getNodesn() != null) {
            VALUES("NODESN", "#{nodesn,jdbcType=VARCHAR}");
        }
        
        if (record.getNodetype() != null) {
            VALUES("NODETYPE", "#{nodetype,jdbcType=VARCHAR}");
        }
        
        if (record.getUsername() != null) {
            VALUES("USERNAME", "#{username,jdbcType=VARCHAR}");
        }
        
        if (record.getCustid() != null) {
            VALUES("CUSTID", "#{custid,jdbcType=VARCHAR}");
        }
        
        if (record.getSvctype() != null) {
            VALUES("SVCTYPE", "#{svctype,jdbcType=CHAR}");
        }
        
        if (record.getUsertype() != null) {
            VALUES("USERTYPE", "#{usertype,jdbcType=CHAR}");
        }
        
        if (record.getConsumptype() != null) {
            VALUES("CONSUMPTYPE", "#{consumptype,jdbcType=CHAR}");
        }
        
        if (record.getConsumpattr() != null) {
            VALUES("CONSUMPATTR", "#{consumpattr,jdbcType=CHAR}");
        }
        
        if (record.getUserstate() != null) {
            VALUES("USERSTATE", "#{userstate,jdbcType=CHAR}");
        }
        
        if (record.getAddrcode() != null) {
            VALUES("ADDRCODE", "#{addrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getAddrdetail() != null) {
            VALUES("ADDRDETAIL", "#{addrdetail,jdbcType=VARCHAR}");
        }
        
        if (record.getStatechngdate() != null) {
            VALUES("STATECHNGDATE", "#{statechngdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getIndustrytype() != null) {
            VALUES("INDUSTRYTYPE", "#{industrytype,jdbcType=VARCHAR}");
        }
        
        if (record.getConsumpdesc() != null) {
            VALUES("CONSUMPDESC", "#{consumpdesc,jdbcType=VARCHAR}");
        }
        
        if (record.getAeratedate() != null) {
            VALUES("AERATEDATE", "#{aeratedate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getHousearea() != null) {
            VALUES("HOUSEAREA", "#{housearea,jdbcType=DECIMAL}");
        }
        
        if (record.getUsersnum() != null) {
            VALUES("USERSNUM", "#{usersnum,jdbcType=DECIMAL}");
        }
        
        if (record.getLatefeeflag() != null) {
            VALUES("LATEFEEFLAG", "#{latefeeflag,jdbcType=CHAR}");
        }
        
        if (record.getMngorg() != null) {
            VALUES("MNGORG", "#{mngorg,jdbcType=VARCHAR}");
        }
        
        if (record.getStenocode() != null) {
            VALUES("STENOCODE", "#{stenocode,jdbcType=VARCHAR}");
        }
        
        if (record.getStenoprompt() != null) {
            VALUES("STENOPROMPT", "#{stenoprompt,jdbcType=VARCHAR}");
        }
        
        if (record.getStenopassword() != null) {
            VALUES("STENOPASSWORD", "#{stenopassword,jdbcType=VARCHAR}");
        }
        
        if (record.getCredit() != null) {
            VALUES("CREDIT", "#{credit,jdbcType=DECIMAL}");
        }
        
        if (record.getArchcode() != null) {
            VALUES("ARCHCODE", "#{archcode,jdbcType=VARCHAR}");
        }
        
        if (record.getChnltype() != null) {
            VALUES("CHNLTYPE", "#{chnltype,jdbcType=CHAR}");
        }
        
        if (record.getChnlid() != null) {
            VALUES("CHNLID", "#{chnlid,jdbcType=VARCHAR}");
        }
        
        if (record.getVer() != null) {
            VALUES("VER", "#{ver,jdbcType=DECIMAL}");
        }
        
        if (record.getNewflag() != null) {
            VALUES("NEWFLAG", "#{newflag,jdbcType=CHAR}");
        }
        
        if (record.getAreapart() != null) {
            VALUES("AREAPART", "#{areapart,jdbcType=CHAR}");
        }
        
        if (record.getOptrcode() != null) {
            VALUES("OPTRCODE", "#{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            VALUES("OPTDATE", "#{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            VALUES("REMARK", "#{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            VALUES("STAND", "#{stand,jdbcType=VARCHAR}");
        }
        
        if (record.getUserlvl() != null) {
            VALUES("USERLVL", "#{userlvl,jdbcType=CHAR}");
        }
        
        return SQL();
    }

    public String updateByPrimaryKeySelective(userinfo record) {
        BEGIN();
        UPDATE("T_BS_USERINFO");
        
        if (record.getBusisn() != null) {
            SET("BUSISN = #{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getBusitype() != null) {
            SET("BUSITYPE = #{busitype,jdbcType=VARCHAR}");
        }
        
        if (record.getNodesn() != null) {
            SET("NODESN = #{nodesn,jdbcType=VARCHAR}");
        }
        
        if (record.getNodetype() != null) {
            SET("NODETYPE = #{nodetype,jdbcType=VARCHAR}");
        }
        
        if (record.getUsername() != null) {
            SET("USERNAME = #{username,jdbcType=VARCHAR}");
        }
        
        if (record.getCustid() != null) {
            SET("CUSTID = #{custid,jdbcType=VARCHAR}");
        }
        
        if (record.getSvctype() != null) {
            SET("SVCTYPE = #{svctype,jdbcType=CHAR}");
        }
        
        if (record.getUsertype() != null) {
            SET("USERTYPE = #{usertype,jdbcType=CHAR}");
        }
        
        if (record.getConsumptype() != null) {
            SET("CONSUMPTYPE = #{consumptype,jdbcType=CHAR}");
        }
        
        if (record.getConsumpattr() != null) {
            SET("CONSUMPATTR = #{consumpattr,jdbcType=CHAR}");
        }
        
        if (record.getUserstate() != null) {
            SET("USERSTATE = #{userstate,jdbcType=CHAR}");
        }
        
        if (record.getAddrcode() != null) {
            SET("ADDRCODE = #{addrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getAddrdetail() != null) {
            SET("ADDRDETAIL = #{addrdetail,jdbcType=VARCHAR}");
        }
        
        if (record.getStatechngdate() != null) {
            SET("STATECHNGDATE = #{statechngdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getIndustrytype() != null) {
            SET("INDUSTRYTYPE = #{industrytype,jdbcType=VARCHAR}");
        }
        
        if (record.getConsumpdesc() != null) {
            SET("CONSUMPDESC = #{consumpdesc,jdbcType=VARCHAR}");
        }
        
        if (record.getAeratedate() != null) {
            SET("AERATEDATE = #{aeratedate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getHousearea() != null) {
            SET("HOUSEAREA = #{housearea,jdbcType=DECIMAL}");
        }
        
        if (record.getUsersnum() != null) {
            SET("USERSNUM = #{usersnum,jdbcType=DECIMAL}");
        }
        
        if (record.getLatefeeflag() != null) {
            SET("LATEFEEFLAG = #{latefeeflag,jdbcType=CHAR}");
        }
        
        if (record.getMngorg() != null) {
            SET("MNGORG = #{mngorg,jdbcType=VARCHAR}");
        }
        
        if (record.getStenocode() != null) {
            SET("STENOCODE = #{stenocode,jdbcType=VARCHAR}");
        }
        
        if (record.getStenoprompt() != null) {
            SET("STENOPROMPT = #{stenoprompt,jdbcType=VARCHAR}");
        }
        
        if (record.getStenopassword() != null) {
            SET("STENOPASSWORD = #{stenopassword,jdbcType=VARCHAR}");
        }
        
        if (record.getCredit() != null) {
            SET("CREDIT = #{credit,jdbcType=DECIMAL}");
        }
        
        if (record.getArchcode() != null) {
            SET("ARCHCODE = #{archcode,jdbcType=VARCHAR}");
        }
        
        if (record.getChnltype() != null) {
            SET("CHNLTYPE = #{chnltype,jdbcType=CHAR}");
        }
        
        if (record.getChnlid() != null) {
            SET("CHNLID = #{chnlid,jdbcType=VARCHAR}");
        }
        
        if (record.getVer() != null) {
            SET("VER = #{ver,jdbcType=DECIMAL}");
        }
        
        if (record.getNewflag() != null) {
            SET("NEWFLAG = #{newflag,jdbcType=CHAR}");
        }
        
        if (record.getAreapart() != null) {
            SET("AREAPART = #{areapart,jdbcType=CHAR}");
        }
        
        if (record.getOptrcode() != null) {
            SET("OPTRCODE = #{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            SET("OPTDATE = #{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            SET("REMARK = #{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            SET("STAND = #{stand,jdbcType=VARCHAR}");
        }
        
        if (record.getUserlvl() != null) {
            SET("USERLVL = #{userlvl,jdbcType=CHAR}");
        }
        
        WHERE("USERID = #{userid,jdbcType=VARCHAR}");
        
        return SQL();
    }
}