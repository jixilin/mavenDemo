package com.ecity.dao;

import com.ecity.entity.addrinfo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface addrinfoMapper {
    @Delete({
        "delete from T_RS_ADDRINFO",
        "where ADDRID = #{addrid,jdbcType=VARCHAR}"
    })
    int deleteByPrimaryKey(String addrid);

    @Insert({
        "insert into T_RS_ADDRINFO (ADDRID, BUSISN, ",
        "FULNAME, LVLNAME, ",
        "ADDRLVL, PARENTADDR, ",
        "ORGCODE, STATE, LASTBUSISN, ",
        "OPTRCODE, OPTDATE)",
        "values (#{addrid,jdbcType=VARCHAR}, #{busisn,jdbcType=VARCHAR}, ",
        "#{fulname,jdbcType=VARCHAR}, #{lvlname,jdbcType=VARCHAR}, ",
        "#{addrlvl,jdbcType=CHAR}, #{parentaddr,jdbcType=VARCHAR}, ",
        "#{orgcode,jdbcType=VARCHAR}, #{state,jdbcType=CHAR}, #{lastbusisn,jdbcType=VARCHAR}, ",
        "#{optrcode,jdbcType=VARCHAR}, #{optdate,jdbcType=TIMESTAMP})"
    })
    int insert(addrinfo record);

    @InsertProvider(type=addrinfoSqlProvider.class, method="insertSelective")
    int insertSelective(addrinfo record);

    @Select({
        "select",
        "ADDRID, BUSISN, FULNAME, LVLNAME, ADDRLVL, PARENTADDR, ORGCODE, STATE, LASTBUSISN, ",
        "OPTRCODE, OPTDATE",
        "from T_RS_ADDRINFO",
        "where ADDRID = #{addrid,jdbcType=VARCHAR}"
    })
    @Results({
        @Result(column="ADDRID", property="addrid", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="BUSISN", property="busisn", jdbcType=JdbcType.VARCHAR),
        @Result(column="FULNAME", property="fulname", jdbcType=JdbcType.VARCHAR),
        @Result(column="LVLNAME", property="lvlname", jdbcType=JdbcType.VARCHAR),
        @Result(column="ADDRLVL", property="addrlvl", jdbcType=JdbcType.CHAR),
        @Result(column="PARENTADDR", property="parentaddr", jdbcType=JdbcType.VARCHAR),
        @Result(column="ORGCODE", property="orgcode", jdbcType=JdbcType.VARCHAR),
        @Result(column="STATE", property="state", jdbcType=JdbcType.CHAR),
        @Result(column="LASTBUSISN", property="lastbusisn", jdbcType=JdbcType.VARCHAR),
        @Result(column="OPTRCODE", property="optrcode", jdbcType=JdbcType.VARCHAR),
        @Result(column="OPTDATE", property="optdate", jdbcType=JdbcType.TIMESTAMP)
    })
    addrinfo selectByPrimaryKey(String addrid);

    @UpdateProvider(type=addrinfoSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(addrinfo record);

    @Update({
        "update T_RS_ADDRINFO",
        "set BUSISN = #{busisn,jdbcType=VARCHAR},",
          "FULNAME = #{fulname,jdbcType=VARCHAR},",
          "LVLNAME = #{lvlname,jdbcType=VARCHAR},",
          "ADDRLVL = #{addrlvl,jdbcType=CHAR},",
          "PARENTADDR = #{parentaddr,jdbcType=VARCHAR},",
          "ORGCODE = #{orgcode,jdbcType=VARCHAR},",
          "STATE = #{state,jdbcType=CHAR},",
          "LASTBUSISN = #{lastbusisn,jdbcType=VARCHAR},",
          "OPTRCODE = #{optrcode,jdbcType=VARCHAR},",
          "OPTDATE = #{optdate,jdbcType=TIMESTAMP}",
        "where ADDRID = #{addrid,jdbcType=VARCHAR}"
    })
    int updateByPrimaryKey(addrinfo record);
}