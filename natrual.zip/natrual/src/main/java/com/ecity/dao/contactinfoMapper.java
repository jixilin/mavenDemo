package com.ecity.dao;

import com.ecity.entity.contactinfo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;

public interface contactinfoMapper {
    @Insert({
        "insert into T_AR_CONTACTINFO (BUSISN, BUSITYPE, ",
        "NODESN, NODETYPE, ",
        "CONTACTID, OWNTYPE, ",
        "OWNID, TYPE, NAME, ",
        "POSITION, DEPTNAME, ",
        "CONTACTPHONE, MOBILE, ",
        "CONTACTADDR, ZIPCODE, ",
        "BIRTHDAY, FAX, EMAIL, ",
        "VER, NEWFLAG, AREAPART, ",
        "OPTRCODE, OPTDATE, ",
        "REMARK, STAND)",
        "values (#{busisn,jdbcType=VARCHAR}, #{busitype,jdbcType=VARCHAR}, ",
        "#{nodesn,jdbcType=VARCHAR}, #{nodetype,jdbcType=VARCHAR}, ",
        "#{contactid,jdbcType=VARCHAR}, #{owntype,jdbcType=CHAR}, ",
        "#{ownid,jdbcType=VARCHAR}, #{type,jdbcType=CHAR}, #{name,jdbcType=VARCHAR}, ",
        "#{position,jdbcType=VARCHAR}, #{deptname,jdbcType=VARCHAR}, ",
        "#{contactphone,jdbcType=VARCHAR}, #{mobile,jdbcType=CHAR}, ",
        "#{contactaddr,jdbcType=VARCHAR}, #{zipcode,jdbcType=CHAR}, ",
        "#{birthday,jdbcType=CHAR}, #{fax,jdbcType=VARCHAR}, #{email,jdbcType=VARCHAR}, ",
        "#{ver,jdbcType=DECIMAL}, #{newflag,jdbcType=CHAR}, #{areapart,jdbcType=CHAR}, ",
        "#{optrcode,jdbcType=VARCHAR}, #{optdate,jdbcType=TIMESTAMP}, ",
        "#{remark,jdbcType=VARCHAR}, #{stand,jdbcType=VARCHAR})"
    })
    int insert(contactinfo record);

    @InsertProvider(type=contactinfoSqlProvider.class, method="insertSelective")
    int insertSelective(contactinfo record);
}