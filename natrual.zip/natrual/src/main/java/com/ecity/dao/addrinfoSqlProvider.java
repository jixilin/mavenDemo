package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SET;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.UPDATE;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;
import static org.apache.ibatis.jdbc.SqlBuilder.WHERE;

import com.ecity.entity.addrinfo;

public class addrinfoSqlProvider {

    public String insertSelective(addrinfo record) {
        BEGIN();
        INSERT_INTO("T_RS_ADDRINFO");
        
        if (record.getAddrid() != null) {
            VALUES("ADDRID", "#{addrid,jdbcType=VARCHAR}");
        }
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getFulname() != null) {
            VALUES("FULNAME", "#{fulname,jdbcType=VARCHAR}");
        }
        
        if (record.getLvlname() != null) {
            VALUES("LVLNAME", "#{lvlname,jdbcType=VARCHAR}");
        }
        
        if (record.getAddrlvl() != null) {
            VALUES("ADDRLVL", "#{addrlvl,jdbcType=CHAR}");
        }
        
        if (record.getParentaddr() != null) {
            VALUES("PARENTADDR", "#{parentaddr,jdbcType=VARCHAR}");
        }
        
        if (record.getOrgcode() != null) {
            VALUES("ORGCODE", "#{orgcode,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            VALUES("STATE", "#{state,jdbcType=CHAR}");
        }
        
        if (record.getLastbusisn() != null) {
            VALUES("LASTBUSISN", "#{lastbusisn,jdbcType=VARCHAR}");
        }
        
        if (record.getOptrcode() != null) {
            VALUES("OPTRCODE", "#{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            VALUES("OPTDATE", "#{optdate,jdbcType=TIMESTAMP}");
        }
        
        return SQL();
    }

    public String updateByPrimaryKeySelective(addrinfo record) {
        BEGIN();
        UPDATE("T_RS_ADDRINFO");
        
        if (record.getBusisn() != null) {
            SET("BUSISN = #{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getFulname() != null) {
            SET("FULNAME = #{fulname,jdbcType=VARCHAR}");
        }
        
        if (record.getLvlname() != null) {
            SET("LVLNAME = #{lvlname,jdbcType=VARCHAR}");
        }
        
        if (record.getAddrlvl() != null) {
            SET("ADDRLVL = #{addrlvl,jdbcType=CHAR}");
        }
        
        if (record.getParentaddr() != null) {
            SET("PARENTADDR = #{parentaddr,jdbcType=VARCHAR}");
        }
        
        if (record.getOrgcode() != null) {
            SET("ORGCODE = #{orgcode,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            SET("STATE = #{state,jdbcType=CHAR}");
        }
        
        if (record.getLastbusisn() != null) {
            SET("LASTBUSISN = #{lastbusisn,jdbcType=VARCHAR}");
        }
        
        if (record.getOptrcode() != null) {
            SET("OPTRCODE = #{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            SET("OPTDATE = #{optdate,jdbcType=TIMESTAMP}");
        }
        
        WHERE("ADDRID = #{addrid,jdbcType=VARCHAR}");
        
        return SQL();
    }
}