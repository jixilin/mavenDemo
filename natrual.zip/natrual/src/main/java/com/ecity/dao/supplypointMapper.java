package com.ecity.dao;

import com.ecity.entity.supplypoint;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;

public interface supplypointMapper {
    @Insert({
        "insert into T_RS_SUPPLYPOINT (BUSISN, PROJECTID, ",
        "SUPPLYPOINTID, RISERID, ",
        "RISERTYPE, STATIONID, ",
        "SOURCETYPE, PRESSFACTOR, ",
        "PRESSLVL, ADDRCODE, ",
        "ADDRDETAIL, STATE, ",
        "MNGORG, LASTBUSISN, ",
        "OPTRCODE, OPTDATE, ",
        "REMARK, STAND)",
        "values (#{busisn,jdbcType=VARCHAR}, #{projectid,jdbcType=VARCHAR}, ",
        "#{supplypointid,jdbcType=VARCHAR}, #{riserid,jdbcType=VARCHAR}, ",
        "#{risertype,jdbcType=CHAR}, #{stationid,jdbcType=VARCHAR}, ",
        "#{sourcetype,jdbcType=CHAR}, #{pressfactor,jdbcType=DECIMAL}, ",
        "#{presslvl,jdbcType=CHAR}, #{addrcode,jdbcType=VARCHAR}, ",
        "#{addrdetail,jdbcType=VARCHAR}, #{state,jdbcType=CHAR}, ",
        "#{mngorg,jdbcType=VARCHAR}, #{lastbusisn,jdbcType=VARCHAR}, ",
        "#{optrcode,jdbcType=VARCHAR}, #{optdate,jdbcType=TIMESTAMP}, ",
        "#{remark,jdbcType=VARCHAR}, #{stand,jdbcType=VARCHAR})"
    })
    int insert(supplypoint record);

    @InsertProvider(type=supplypointSqlProvider.class, method="insertSelective")
    int insertSelective(supplypoint record);
}