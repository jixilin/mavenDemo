package com.ecity.dao;

import com.ecity.entity.userinfo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;
import org.springframework.stereotype.Repository;

@Repository
public interface userinfoMapper {
    @Delete({
        "delete from T_BS_USERINFO",
        "where USERID = #{userid,jdbcType=VARCHAR}"
    })
    int deleteByPrimaryKey(String userid);

    @Insert({
        "insert into T_BS_USERINFO (USERID, BUSISN, ",
        "BUSITYPE, NODESN, ",
        "NODETYPE, USERNAME, ",
        "CUSTID, SVCTYPE, USERTYPE, ",
        "CONSUMPTYPE, CONSUMPATTR, ",
        "USERSTATE, ADDRCODE, ",
        "ADDRDETAIL, STATECHNGDATE, ",
        "INDUSTRYTYPE, CONSUMPDESC, ",
        "AERATEDATE, HOUSEAREA, ",
        "USERSNUM, LATEFEEFLAG, ",
        "MNGORG, STENOCODE, ",
        "STENOPROMPT, STENOPASSWORD, ",
        "CREDIT, ARCHCODE, ",
        "CHNLTYPE, CHNLID, VER, ",
        "NEWFLAG, AREAPART, OPTRCODE, ",
        "OPTDATE, REMARK, ",
        "STAND, USERLVL)",
        "values (#{userid,jdbcType=VARCHAR}, #{busisn,jdbcType=VARCHAR}, ",
        "#{busitype,jdbcType=VARCHAR}, #{nodesn,jdbcType=VARCHAR}, ",
        "#{nodetype,jdbcType=VARCHAR}, #{username,jdbcType=VARCHAR}, ",
        "#{custid,jdbcType=VARCHAR}, #{svctype,jdbcType=CHAR}, #{usertype,jdbcType=CHAR}, ",
        "#{consumptype,jdbcType=CHAR}, #{consumpattr,jdbcType=CHAR}, ",
        "#{userstate,jdbcType=CHAR}, #{addrcode,jdbcType=VARCHAR}, ",
        "#{addrdetail,jdbcType=VARCHAR}, #{statechngdate,jdbcType=TIMESTAMP}, ",
        "#{industrytype,jdbcType=VARCHAR}, #{consumpdesc,jdbcType=VARCHAR}, ",
        "#{aeratedate,jdbcType=TIMESTAMP}, #{housearea,jdbcType=DECIMAL}, ",
        "#{usersnum,jdbcType=DECIMAL}, #{latefeeflag,jdbcType=CHAR}, ",
        "#{mngorg,jdbcType=VARCHAR}, #{stenocode,jdbcType=VARCHAR}, ",
        "#{stenoprompt,jdbcType=VARCHAR}, #{stenopassword,jdbcType=VARCHAR}, ",
        "#{credit,jdbcType=DECIMAL}, #{archcode,jdbcType=VARCHAR}, ",
        "#{chnltype,jdbcType=CHAR}, #{chnlid,jdbcType=VARCHAR}, #{ver,jdbcType=DECIMAL}, ",
        "#{newflag,jdbcType=CHAR}, #{areapart,jdbcType=CHAR}, #{optrcode,jdbcType=VARCHAR}, ",
        "#{optdate,jdbcType=TIMESTAMP}, #{remark,jdbcType=VARCHAR}, ",
        "#{stand,jdbcType=VARCHAR}, #{userlvl,jdbcType=CHAR})"
    })
    int insert(userinfo record);

    @InsertProvider(type=userinfoSqlProvider.class, method="insertSelective")
    int insertSelective(userinfo record);

    @Select({
        "select",
        "USERID, BUSISN, BUSITYPE, NODESN, NODETYPE, USERNAME, CUSTID, SVCTYPE, USERTYPE, ",
        "CONSUMPTYPE, CONSUMPATTR, USERSTATE, ADDRCODE, ADDRDETAIL, STATECHNGDATE, INDUSTRYTYPE, ",
        "CONSUMPDESC, AERATEDATE, HOUSEAREA, USERSNUM, LATEFEEFLAG, MNGORG, STENOCODE, ",
        "STENOPROMPT, STENOPASSWORD, CREDIT, ARCHCODE, CHNLTYPE, CHNLID, VER, NEWFLAG, ",
        "AREAPART, OPTRCODE, OPTDATE, REMARK, STAND, USERLVL",
        "from T_BS_USERINFO",
        "where USERID = #{userid,jdbcType=VARCHAR}"
    })
    @Results({
        @Result(column="USERID", property="userid", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="BUSISN", property="busisn", jdbcType=JdbcType.VARCHAR),
        @Result(column="BUSITYPE", property="busitype", jdbcType=JdbcType.VARCHAR),
        @Result(column="NODESN", property="nodesn", jdbcType=JdbcType.VARCHAR),
        @Result(column="NODETYPE", property="nodetype", jdbcType=JdbcType.VARCHAR),
        @Result(column="USERNAME", property="username", jdbcType=JdbcType.VARCHAR),
        @Result(column="CUSTID", property="custid", jdbcType=JdbcType.VARCHAR),
        @Result(column="SVCTYPE", property="svctype", jdbcType=JdbcType.CHAR),
        @Result(column="USERTYPE", property="usertype", jdbcType=JdbcType.CHAR),
        @Result(column="CONSUMPTYPE", property="consumptype", jdbcType=JdbcType.CHAR),
        @Result(column="CONSUMPATTR", property="consumpattr", jdbcType=JdbcType.CHAR),
        @Result(column="USERSTATE", property="userstate", jdbcType=JdbcType.CHAR),
        @Result(column="ADDRCODE", property="addrcode", jdbcType=JdbcType.VARCHAR),
        @Result(column="ADDRDETAIL", property="addrdetail", jdbcType=JdbcType.VARCHAR),
        @Result(column="STATECHNGDATE", property="statechngdate", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="INDUSTRYTYPE", property="industrytype", jdbcType=JdbcType.VARCHAR),
        @Result(column="CONSUMPDESC", property="consumpdesc", jdbcType=JdbcType.VARCHAR),
        @Result(column="AERATEDATE", property="aeratedate", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="HOUSEAREA", property="housearea", jdbcType=JdbcType.DECIMAL),
        @Result(column="USERSNUM", property="usersnum", jdbcType=JdbcType.DECIMAL),
        @Result(column="LATEFEEFLAG", property="latefeeflag", jdbcType=JdbcType.CHAR),
        @Result(column="MNGORG", property="mngorg", jdbcType=JdbcType.VARCHAR),
        @Result(column="STENOCODE", property="stenocode", jdbcType=JdbcType.VARCHAR),
        @Result(column="STENOPROMPT", property="stenoprompt", jdbcType=JdbcType.VARCHAR),
        @Result(column="STENOPASSWORD", property="stenopassword", jdbcType=JdbcType.VARCHAR),
        @Result(column="CREDIT", property="credit", jdbcType=JdbcType.DECIMAL),
        @Result(column="ARCHCODE", property="archcode", jdbcType=JdbcType.VARCHAR),
        @Result(column="CHNLTYPE", property="chnltype", jdbcType=JdbcType.CHAR),
        @Result(column="CHNLID", property="chnlid", jdbcType=JdbcType.VARCHAR),
        @Result(column="VER", property="ver", jdbcType=JdbcType.DECIMAL),
        @Result(column="NEWFLAG", property="newflag", jdbcType=JdbcType.CHAR),
        @Result(column="AREAPART", property="areapart", jdbcType=JdbcType.CHAR),
        @Result(column="OPTRCODE", property="optrcode", jdbcType=JdbcType.VARCHAR),
        @Result(column="OPTDATE", property="optdate", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="REMARK", property="remark", jdbcType=JdbcType.VARCHAR),
        @Result(column="STAND", property="stand", jdbcType=JdbcType.VARCHAR),
        @Result(column="USERLVL", property="userlvl", jdbcType=JdbcType.CHAR)
    })
    userinfo selectByPrimaryKey(String userid);

    @UpdateProvider(type=userinfoSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(userinfo record);

    @Update({
        "update T_BS_USERINFO",
        "set BUSISN = #{busisn,jdbcType=VARCHAR},",
          "BUSITYPE = #{busitype,jdbcType=VARCHAR},",
          "NODESN = #{nodesn,jdbcType=VARCHAR},",
          "NODETYPE = #{nodetype,jdbcType=VARCHAR},",
          "USERNAME = #{username,jdbcType=VARCHAR},",
          "CUSTID = #{custid,jdbcType=VARCHAR},",
          "SVCTYPE = #{svctype,jdbcType=CHAR},",
          "USERTYPE = #{usertype,jdbcType=CHAR},",
          "CONSUMPTYPE = #{consumptype,jdbcType=CHAR},",
          "CONSUMPATTR = #{consumpattr,jdbcType=CHAR},",
          "USERSTATE = #{userstate,jdbcType=CHAR},",
          "ADDRCODE = #{addrcode,jdbcType=VARCHAR},",
          "ADDRDETAIL = #{addrdetail,jdbcType=VARCHAR},",
          "STATECHNGDATE = #{statechngdate,jdbcType=TIMESTAMP},",
          "INDUSTRYTYPE = #{industrytype,jdbcType=VARCHAR},",
          "CONSUMPDESC = #{consumpdesc,jdbcType=VARCHAR},",
          "AERATEDATE = #{aeratedate,jdbcType=TIMESTAMP},",
          "HOUSEAREA = #{housearea,jdbcType=DECIMAL},",
          "USERSNUM = #{usersnum,jdbcType=DECIMAL},",
          "LATEFEEFLAG = #{latefeeflag,jdbcType=CHAR},",
          "MNGORG = #{mngorg,jdbcType=VARCHAR},",
          "STENOCODE = #{stenocode,jdbcType=VARCHAR},",
          "STENOPROMPT = #{stenoprompt,jdbcType=VARCHAR},",
          "STENOPASSWORD = #{stenopassword,jdbcType=VARCHAR},",
          "CREDIT = #{credit,jdbcType=DECIMAL},",
          "ARCHCODE = #{archcode,jdbcType=VARCHAR},",
          "CHNLTYPE = #{chnltype,jdbcType=CHAR},",
          "CHNLID = #{chnlid,jdbcType=VARCHAR},",
          "VER = #{ver,jdbcType=DECIMAL},",
          "NEWFLAG = #{newflag,jdbcType=CHAR},",
          "AREAPART = #{areapart,jdbcType=CHAR},",
          "OPTRCODE = #{optrcode,jdbcType=VARCHAR},",
          "OPTDATE = #{optdate,jdbcType=TIMESTAMP},",
          "REMARK = #{remark,jdbcType=VARCHAR},",
          "STAND = #{stand,jdbcType=VARCHAR},",
          "USERLVL = #{userlvl,jdbcType=CHAR}",
        "where USERID = #{userid,jdbcType=VARCHAR}"
    })
    int updateByPrimaryKey(userinfo record);
}