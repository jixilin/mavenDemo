package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SET;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.UPDATE;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;
import static org.apache.ibatis.jdbc.SqlBuilder.WHERE;

import com.ecity.entity.divbuilding;

public class divbuildingSqlProvider {

    public String insertSelective(divbuilding record) {
        BEGIN();
        INSERT_INTO("T_SS_DIVBUILDING");
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getDivid() != null) {
            VALUES("DIVID", "#{divid,jdbcType=VARCHAR}");
        }
        
        if (record.getBuildingid() != null) {
            VALUES("BUILDINGID", "#{buildingid,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            VALUES("STATE", "#{state,jdbcType=CHAR}");
        }
        
        if (record.getBatchid() != null) {
            VALUES("BATCHID", "#{batchid,jdbcType=VARCHAR}");
        }
        
        if (record.getOldbusisn() != null) {
            VALUES("OLDBUSISN", "#{oldbusisn,jdbcType=VARCHAR}");
        }
        
        return SQL();
    }

    public String updateByPrimaryKeySelective(divbuilding record) {
        BEGIN();
        UPDATE("T_SS_DIVBUILDING");
        
        if (record.getDivid() != null) {
            SET("DIVID = #{divid,jdbcType=VARCHAR}");
        }
        
        if (record.getBuildingid() != null) {
            SET("BUILDINGID = #{buildingid,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            SET("STATE = #{state,jdbcType=CHAR}");
        }
        
        if (record.getBatchid() != null) {
            SET("BATCHID = #{batchid,jdbcType=VARCHAR}");
        }
        
        if (record.getOldbusisn() != null) {
            SET("OLDBUSISN = #{oldbusisn,jdbcType=VARCHAR}");
        }
        
        WHERE("BUSISN = #{busisn,jdbcType=VARCHAR}");
        
        return SQL();
    }
}