package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;

import com.ecity.entity.supplypoint;

public class supplypointSqlProvider {

    public String insertSelective(supplypoint record) {
        BEGIN();
        INSERT_INTO("T_RS_SUPPLYPOINT");
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getProjectid() != null) {
            VALUES("PROJECTID", "#{projectid,jdbcType=VARCHAR}");
        }
        
        if (record.getSupplypointid() != null) {
            VALUES("SUPPLYPOINTID", "#{supplypointid,jdbcType=VARCHAR}");
        }
        
        if (record.getRiserid() != null) {
            VALUES("RISERID", "#{riserid,jdbcType=VARCHAR}");
        }
        
        if (record.getRisertype() != null) {
            VALUES("RISERTYPE", "#{risertype,jdbcType=CHAR}");
        }
        
        if (record.getStationid() != null) {
            VALUES("STATIONID", "#{stationid,jdbcType=VARCHAR}");
        }
        
        if (record.getSourcetype() != null) {
            VALUES("SOURCETYPE", "#{sourcetype,jdbcType=CHAR}");
        }
        
        if (record.getPressfactor() != null) {
            VALUES("PRESSFACTOR", "#{pressfactor,jdbcType=DECIMAL}");
        }
        
        if (record.getPresslvl() != null) {
            VALUES("PRESSLVL", "#{presslvl,jdbcType=CHAR}");
        }
        
        if (record.getAddrcode() != null) {
            VALUES("ADDRCODE", "#{addrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getAddrdetail() != null) {
            VALUES("ADDRDETAIL", "#{addrdetail,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            VALUES("STATE", "#{state,jdbcType=CHAR}");
        }
        
        if (record.getMngorg() != null) {
            VALUES("MNGORG", "#{mngorg,jdbcType=VARCHAR}");
        }
        
        if (record.getLastbusisn() != null) {
            VALUES("LASTBUSISN", "#{lastbusisn,jdbcType=VARCHAR}");
        }
        
        if (record.getOptrcode() != null) {
            VALUES("OPTRCODE", "#{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            VALUES("OPTDATE", "#{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            VALUES("REMARK", "#{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            VALUES("STAND", "#{stand,jdbcType=VARCHAR}");
        }
        
        return SQL();
    }
}