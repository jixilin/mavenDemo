package com.ecity.dao;

import com.ecity.entity.divbuilding;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface divbuildingMapper {
    @Delete({
        "delete from T_SS_DIVBUILDING",
        "where BUSISN = #{busisn,jdbcType=VARCHAR}"
    })
    int deleteByPrimaryKey(String busisn);

    @Insert({
        "insert into T_SS_DIVBUILDING (BUSISN, DIVID, ",
        "BUILDINGID, STATE, ",
        "BATCHID, OLDBUSISN)",
        "values (#{busisn,jdbcType=VARCHAR}, #{divid,jdbcType=VARCHAR}, ",
        "#{buildingid,jdbcType=VARCHAR}, #{state,jdbcType=CHAR}, ",
        "#{batchid,jdbcType=VARCHAR}, #{oldbusisn,jdbcType=VARCHAR})"
    })
    int insert(divbuilding record);

    @InsertProvider(type=divbuildingSqlProvider.class, method="insertSelective")
    int insertSelective(divbuilding record);

    @Select({
        "select",
        "BUSISN, DIVID, BUILDINGID, STATE, BATCHID, OLDBUSISN",
        "from T_SS_DIVBUILDING",
        "where BUSISN = #{busisn,jdbcType=VARCHAR}"
    })
    @Results({
        @Result(column="BUSISN", property="busisn", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="DIVID", property="divid", jdbcType=JdbcType.VARCHAR),
        @Result(column="BUILDINGID", property="buildingid", jdbcType=JdbcType.VARCHAR),
        @Result(column="STATE", property="state", jdbcType=JdbcType.CHAR),
        @Result(column="BATCHID", property="batchid", jdbcType=JdbcType.VARCHAR),
        @Result(column="OLDBUSISN", property="oldbusisn", jdbcType=JdbcType.VARCHAR)
    })
    divbuilding selectByPrimaryKey(String busisn);

    @UpdateProvider(type=divbuildingSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(divbuilding record);

    @Update({
        "update T_SS_DIVBUILDING",
        "set DIVID = #{divid,jdbcType=VARCHAR},",
          "BUILDINGID = #{buildingid,jdbcType=VARCHAR},",
          "STATE = #{state,jdbcType=CHAR},",
          "BATCHID = #{batchid,jdbcType=VARCHAR},",
          "OLDBUSISN = #{oldbusisn,jdbcType=VARCHAR}",
        "where BUSISN = #{busisn,jdbcType=VARCHAR}"
    })
    int updateByPrimaryKey(divbuilding record);
}