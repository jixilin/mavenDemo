package com.ecity.dao;


import static org.apache.ibatis.jdbc.SqlBuilder.*;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;

/**
 * Created by Administrator on 2017/6/27.
 */
public class BuildinggeoProvider {

    public String selectAllBind(String states,String geoids) {

        BEGIN();
        SELECT("GEOID");
        SELECT("BUILDINGID");
        SELECT("STATE");
        SELECT("ADDRCODE");
        SELECT("X");
        SELECT("Y");
        FROM("T_SS_BUILDINGGEO");
        if (states != null && geoids != null) {
            WHERE("GEOID = #{0} AND STATE = #{1}");
        } else if (geoids == null) {
            WHERE("STATE = #{0}");
        }
        return SQL();
    }
}
