package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SET;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.UPDATE;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;
import static org.apache.ibatis.jdbc.SqlBuilder.WHERE;

import com.ecity.entity.division;

public class divisionSqlProvider {

    public String insertSelective(division record) {
        BEGIN();
        INSERT_INTO("T_SS_DIVISION");
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getBusisnhis() != null) {
            VALUES("BUSISNHIS", "#{busisnhis,jdbcType=VARCHAR}");
        }
        
        if (record.getOrgcode() != null) {
            VALUES("ORGCODE", "#{orgcode,jdbcType=VARCHAR}");
        }
        
        if (record.getDivid() != null) {
            VALUES("DIVID", "#{divid,jdbcType=VARCHAR}");
        }
        
        if (record.getDivname() != null) {
            VALUES("DIVNAME", "#{divname,jdbcType=VARCHAR}");
        }
        
        if (record.getParentdivid() != null) {
            VALUES("PARENTDIVID", "#{parentdivid,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            VALUES("STATE", "#{state,jdbcType=CHAR}");
        }
        
        if (record.getOptrcode() != null) {
            VALUES("OPTRCODE", "#{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            VALUES("OPTDATE", "#{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            VALUES("REMARK", "#{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            VALUES("STAND", "#{stand,jdbcType=VARCHAR}");
        }
        
        if (record.getAreatype() != null) {
            VALUES("AREATYPE", "#{areatype,jdbcType=VARCHAR}");
        }
        
        return SQL();
    }

    public String updateByPrimaryKeySelective(division record) {
        BEGIN();
        UPDATE("T_SS_DIVISION");
        
        if (record.getBusisnhis() != null) {
            SET("BUSISNHIS = #{busisnhis,jdbcType=VARCHAR}");
        }
        
        if (record.getOrgcode() != null) {
            SET("ORGCODE = #{orgcode,jdbcType=VARCHAR}");
        }
        
        if (record.getDivid() != null) {
            SET("DIVID = #{divid,jdbcType=VARCHAR}");
        }
        
        if (record.getDivname() != null) {
            SET("DIVNAME = #{divname,jdbcType=VARCHAR}");
        }
        
        if (record.getParentdivid() != null) {
            SET("PARENTDIVID = #{parentdivid,jdbcType=VARCHAR}");
        }
        
        if (record.getState() != null) {
            SET("STATE = #{state,jdbcType=CHAR}");
        }
        
        if (record.getOptrcode() != null) {
            SET("OPTRCODE = #{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            SET("OPTDATE = #{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            SET("REMARK = #{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            SET("STAND = #{stand,jdbcType=VARCHAR}");
        }
        
        if (record.getAreatype() != null) {
            SET("AREATYPE = #{areatype,jdbcType=VARCHAR}");
        }
        
        WHERE("BUSISN = #{busisn,jdbcType=VARCHAR}");
        
        return SQL();
    }
    public String index() {

        return "select * from T_SS_DIVISION t start with t.Parentdivid = '0' connect by prior t.divid = t.Parentdivid";
    }
}