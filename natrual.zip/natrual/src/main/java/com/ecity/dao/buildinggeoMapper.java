package com.ecity.dao;

import com.ecity.entity.buildinggeo;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface buildinggeoMapper {

    /*获取所有已绑定的建筑物*/
    //@Select("select GEOID from T_SS_BUILDINGGEO where state = #{state}")
    @ResultMap("BaseResultMap")
    @SelectProvider(type = BuildinggeoProvider.class,method = "selectAllBind")
    List<buildinggeo> selectAllBind(String state,String geoid);
}