package com.ecity.dao;

import static org.apache.ibatis.jdbc.SqlBuilder.BEGIN;
import static org.apache.ibatis.jdbc.SqlBuilder.INSERT_INTO;
import static org.apache.ibatis.jdbc.SqlBuilder.SQL;
import static org.apache.ibatis.jdbc.SqlBuilder.VALUES;

import com.ecity.entity.usermeter;

public class usermeterSqlProvider {

    public String insertSelective(usermeter record) {
        BEGIN();
        INSERT_INTO("T_BS_USERMETER");
        
        if (record.getBusisn() != null) {
            VALUES("BUSISN", "#{busisn,jdbcType=VARCHAR}");
        }
        
        if (record.getBusitype() != null) {
            VALUES("BUSITYPE", "#{busitype,jdbcType=VARCHAR}");
        }
        
        if (record.getNodesn() != null) {
            VALUES("NODESN", "#{nodesn,jdbcType=VARCHAR}");
        }
        
        if (record.getNodetype() != null) {
            VALUES("NODETYPE", "#{nodetype,jdbcType=VARCHAR}");
        }
        
        if (record.getUserid() != null) {
            VALUES("USERID", "#{userid,jdbcType=VARCHAR}");
        }
        
        if (record.getBarcode() != null) {
            VALUES("BARCODE", "#{barcode,jdbcType=VARCHAR}");
        }
        
        if (record.getResid() != null) {
            VALUES("RESID", "#{resid,jdbcType=VARCHAR}");
        }
        
        if (record.getSupplypointid() != null) {
            VALUES("SUPPLYPOINTID", "#{supplypointid,jdbcType=VARCHAR}");
        }
        
        if (record.getRestype() != null) {
            VALUES("RESTYPE", "#{restype,jdbcType=VARCHAR}");
        }
        
        if (record.getFactoryid() != null) {
            VALUES("FACTORYID", "#{factoryid,jdbcType=VARCHAR}");
        }
        
        if (record.getModelid() != null) {
            VALUES("MODELID", "#{modelid,jdbcType=VARCHAR}");
        }
        
        if (record.getPress() != null) {
            VALUES("PRESS", "#{press,jdbcType=VARCHAR}");
        }
        
        if (record.getCaliber() != null) {
            VALUES("CALIBER", "#{caliber,jdbcType=VARCHAR}");
        }
        
        if (record.getRange() != null) {
            VALUES("RANGE", "#{range,jdbcType=DECIMAL}");
        }
        
        if (record.getRate() != null) {
            VALUES("RATE", "#{rate,jdbcType=DECIMAL}");
        }
        
        if (record.getFixdirect() != null) {
            VALUES("FIXDIRECT", "#{fixdirect,jdbcType=CHAR}");
        }
        
        if (record.getMeterdirect() != null) {
            VALUES("METERDIRECT", "#{meterdirect,jdbcType=CHAR}");
        }
        
        if (record.getIsbill() != null) {
            VALUES("ISBILL", "#{isbill,jdbcType=CHAR}");
        }
        
        if (record.getIsbranch() != null) {
            VALUES("ISBRANCH", "#{isbranch,jdbcType=CHAR}");
        }
        
        if (record.getIsblind() != null) {
            VALUES("ISBLIND", "#{isblind,jdbcType=CHAR}");
        }
        
        if (record.getIsseal() != null) {
            VALUES("ISSEAL", "#{isseal,jdbcType=CHAR}");
        }
        
        if (record.getIsbuy() != null) {
            VALUES("ISBUY", "#{isbuy,jdbcType=CHAR}");
        }
        
        if (record.getOilunit() != null) {
            VALUES("OILUNIT", "#{oilunit,jdbcType=CHAR}");
        }
        
        if (record.getOilcycle() != null) {
            VALUES("OILCYCLE", "#{oilcycle,jdbcType=VARCHAR}");
        }
        
        if (record.getCheckcycle() != null) {
            VALUES("CHECKCYCLE", "#{checkcycle,jdbcType=VARCHAR}");
        }
        
        if (record.getOilnext() != null) {
            VALUES("OILNEXT", "#{oilnext,jdbcType=TIMESTAMP}");
        }
        
        if (record.getChecknext() != null) {
            VALUES("CHECKNEXT", "#{checknext,jdbcType=TIMESTAMP}");
        }
        
        if (record.getFixdate() != null) {
            VALUES("FIXDATE", "#{fixdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemovedate() != null) {
            VALUES("REMOVEDATE", "#{removedate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getMeterbox() != null) {
            VALUES("METERBOX", "#{meterbox,jdbcType=VARCHAR}");
        }
        
        if (record.getPosinum() != null) {
            VALUES("POSINUM", "#{posinum,jdbcType=VARCHAR}");
        }
        
        if (record.getFixmode() != null) {
            VALUES("FIXMODE", "#{fixmode,jdbcType=CHAR}");
        }
        
        if (record.getMeterposi() != null) {
            VALUES("METERPOSI", "#{meterposi,jdbcType=VARCHAR}");
        }
        
        if (record.getCarddirect() != null) {
            VALUES("CARDDIRECT", "#{carddirect,jdbcType=CHAR}");
        }
        
        if (record.getEnv() != null) {
            VALUES("ENV", "#{env,jdbcType=VARCHAR}");
        }
        
        if (record.getIssafety() != null) {
            VALUES("ISSAFETY", "#{issafety,jdbcType=CHAR}");
        }
        
        if (record.getTemppressfactor() != null) {
            VALUES("TEMPPRESSFACTOR", "#{temppressfactor,jdbcType=DECIMAL}");
        }
        
        if (record.getAdjustfactor() != null) {
            VALUES("ADJUSTFACTOR", "#{adjustfactor,jdbcType=DECIMAL}");
        }
        
        if (record.getImgcode() != null) {
            VALUES("IMGCODE", "#{imgcode,jdbcType=VARCHAR}");
        }
        
        if (record.getSealcode() != null) {
            VALUES("SEALCODE", "#{sealcode,jdbcType=VARCHAR}");
        }
        
        if (record.getModifiercode() != null) {
            VALUES("MODIFIERCODE", "#{modifiercode,jdbcType=VARCHAR}");
        }
        
        if (record.getBasefactor() != null) {
            VALUES("BASEFACTOR", "#{basefactor,jdbcType=DECIMAL}");
        }
        
        if (record.getState() != null) {
            VALUES("STATE", "#{state,jdbcType=CHAR}");
        }
        
        if (record.getVer() != null) {
            VALUES("VER", "#{ver,jdbcType=DECIMAL}");
        }
        
        if (record.getNewflag() != null) {
            VALUES("NEWFLAG", "#{newflag,jdbcType=CHAR}");
        }
        
        if (record.getAreapart() != null) {
            VALUES("AREAPART", "#{areapart,jdbcType=CHAR}");
        }
        
        if (record.getOptrcode() != null) {
            VALUES("OPTRCODE", "#{optrcode,jdbcType=VARCHAR}");
        }
        
        if (record.getOptdate() != null) {
            VALUES("OPTDATE", "#{optdate,jdbcType=TIMESTAMP}");
        }
        
        if (record.getRemark() != null) {
            VALUES("REMARK", "#{remark,jdbcType=VARCHAR}");
        }
        
        if (record.getStand() != null) {
            VALUES("STAND", "#{stand,jdbcType=VARCHAR}");
        }
        
        return SQL();
    }
}