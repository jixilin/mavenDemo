package com.ecity.dao;



public class buildingSqlProvider {

    public String getdetail(String divid) {

        return "select t.buildingid,t.buildingname,t.addrcode,r.fulname,g.state,g.x,g.y  from t_rs_building t left join t_ss_divbuilding s on t.buildingid = s.buildingid left join t_ss_buildinggeo g on t.buildingid = g.buildingid  left join t_ss_division d on s.divid = d.divid left join t_rs_addrinfo r on t.addrcode = r.addrid where s.divid = '"+divid+"'";
    }
}