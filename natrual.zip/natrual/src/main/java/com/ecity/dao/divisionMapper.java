package com.ecity.dao;

import com.ecity.entity.division;
import net.sf.jsqlparser.expression.operators.arithmetic.Division;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface divisionMapper {

    /** 获取栋与楼层、用户之间相关信息*/
    @Results({
            @Result(column="BUSISN", property="busisn", jdbcType=JdbcType.VARCHAR, id=true),
            @Result(column="BUSISNHIS", property="busisnhis", jdbcType=JdbcType.VARCHAR),
            @Result(column="ORGCODE", property="orgcode", jdbcType=JdbcType.VARCHAR),
            @Result(column="DIVID", property="divid", jdbcType=JdbcType.VARCHAR),
            @Result(column="DIVNAME", property="divname", jdbcType=JdbcType.VARCHAR),
            @Result(column="PARENTDIVID", property="parentdivid", jdbcType=JdbcType.VARCHAR),
            @Result(column="STATE", property="state", jdbcType=JdbcType.CHAR),
            @Result(column="OPTRCODE", property="optrcode", jdbcType=JdbcType.VARCHAR),
            @Result(column="OPTDATE", property="optdate", jdbcType=JdbcType.TIMESTAMP),
            @Result(column="REMARK", property="remark", jdbcType=JdbcType.VARCHAR),
            @Result(column="STAND", property="stand", jdbcType=JdbcType.VARCHAR),
            @Result(column="AREATYPE", property="areatype", jdbcType=JdbcType.VARCHAR)
    })
    @SelectProvider(type=divisionSqlProvider.class,method ="index" )
    List<division> index();

}