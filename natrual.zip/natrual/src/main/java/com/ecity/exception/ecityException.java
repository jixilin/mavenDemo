package com.ecity.exception;

/**
 * Created by Administrator on 2017/6/6.
 */
public class ecityException  extends RuntimeException{

    public ecityException() {super();}
    public ecityException(String msg){super(msg);}
    public ecityException(String msg, Throwable throwable) {super(msg, throwable);}

}
