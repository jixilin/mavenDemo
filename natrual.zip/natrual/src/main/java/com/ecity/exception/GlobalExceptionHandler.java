/**
 * 
 */
package com.ecity.exception;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;

import com.ecity.bean.Code;
import com.ecity.bean.DataResponse;
import com.ecity.utils.ResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = { NoHandlerFoundException.class })
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public DataResponse noHandlerFoundException(Exception ex) {
		return ResponseUtil.response(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
	}

	@ExceptionHandler(value = { ConstraintViolationException.class })
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public DataResponse constraintViolationException(ConstraintViolationException ex) {
		return ResponseUtil.response(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase());
	}

	@ExceptionHandler(value = Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public DataResponse defaultErrorHandler(HttpServletRequest request, Exception exception) throws Exception {
		return ResponseUtil.response(HttpStatus.INTERNAL_SERVER_ERROR.value(), exception.getMessage());
	}
	@ExceptionHandler(value = ecityException.class)
	public DataResponse defaultErrorHandler(HttpServletRequest request, ecityException exception) throws Exception {
		return ResponseUtil.response(Code.FAIL, exception.getMessage());
	}

}
