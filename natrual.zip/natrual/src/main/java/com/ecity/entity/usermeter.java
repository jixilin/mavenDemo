package com.ecity.entity;

import java.math.BigDecimal;
import java.util.Date;

public class usermeter {
    private String busisn;

    private String busitype;

    private String nodesn;

    private String nodetype;

    private String userid;

    private String barcode;

    private String resid;

    private String supplypointid;

    private String restype;

    private String factoryid;

    private String modelid;

    private String press;

    private String caliber;

    private Long range;

    private Long rate;

    private String fixdirect;

    private String meterdirect;

    private String isbill;

    private String isbranch;

    private String isblind;

    private String isseal;

    private String isbuy;

    private String oilunit;

    private String oilcycle;

    private String checkcycle;

    private Date oilnext;

    private Date checknext;

    private Date fixdate;

    private Date removedate;

    private String meterbox;

    private String posinum;

    private String fixmode;

    private String meterposi;

    private String carddirect;

    private String env;

    private String issafety;

    private BigDecimal temppressfactor;

    private BigDecimal adjustfactor;

    private String imgcode;

    private String sealcode;

    private String modifiercode;

    private BigDecimal basefactor;

    private String state;

    private Long ver;

    private String newflag;

    private String areapart;

    private String optrcode;

    private Date optdate;

    private String remark;

    private String stand;

    public String getBusisn() {
        return busisn;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getBusitype() {
        return busitype;
    }

    public void setBusitype(String busitype) {
        this.busitype = busitype == null ? null : busitype.trim();
    }

    public String getNodesn() {
        return nodesn;
    }

    public void setNodesn(String nodesn) {
        this.nodesn = nodesn == null ? null : nodesn.trim();
    }

    public String getNodetype() {
        return nodetype;
    }

    public void setNodetype(String nodetype) {
        this.nodetype = nodetype == null ? null : nodetype.trim();
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode == null ? null : barcode.trim();
    }

    public String getResid() {
        return resid;
    }

    public void setResid(String resid) {
        this.resid = resid == null ? null : resid.trim();
    }

    public String getSupplypointid() {
        return supplypointid;
    }

    public void setSupplypointid(String supplypointid) {
        this.supplypointid = supplypointid == null ? null : supplypointid.trim();
    }

    public String getRestype() {
        return restype;
    }

    public void setRestype(String restype) {
        this.restype = restype == null ? null : restype.trim();
    }

    public String getFactoryid() {
        return factoryid;
    }

    public void setFactoryid(String factoryid) {
        this.factoryid = factoryid == null ? null : factoryid.trim();
    }

    public String getModelid() {
        return modelid;
    }

    public void setModelid(String modelid) {
        this.modelid = modelid == null ? null : modelid.trim();
    }

    public String getPress() {
        return press;
    }

    public void setPress(String press) {
        this.press = press == null ? null : press.trim();
    }

    public String getCaliber() {
        return caliber;
    }

    public void setCaliber(String caliber) {
        this.caliber = caliber == null ? null : caliber.trim();
    }

    public Long getRange() {
        return range;
    }

    public void setRange(Long range) {
        this.range = range;
    }

    public Long getRate() {
        return rate;
    }

    public void setRate(Long rate) {
        this.rate = rate;
    }

    public String getFixdirect() {
        return fixdirect;
    }

    public void setFixdirect(String fixdirect) {
        this.fixdirect = fixdirect == null ? null : fixdirect.trim();
    }

    public String getMeterdirect() {
        return meterdirect;
    }

    public void setMeterdirect(String meterdirect) {
        this.meterdirect = meterdirect == null ? null : meterdirect.trim();
    }

    public String getIsbill() {
        return isbill;
    }

    public void setIsbill(String isbill) {
        this.isbill = isbill == null ? null : isbill.trim();
    }

    public String getIsbranch() {
        return isbranch;
    }

    public void setIsbranch(String isbranch) {
        this.isbranch = isbranch == null ? null : isbranch.trim();
    }

    public String getIsblind() {
        return isblind;
    }

    public void setIsblind(String isblind) {
        this.isblind = isblind == null ? null : isblind.trim();
    }

    public String getIsseal() {
        return isseal;
    }

    public void setIsseal(String isseal) {
        this.isseal = isseal == null ? null : isseal.trim();
    }

    public String getIsbuy() {
        return isbuy;
    }

    public void setIsbuy(String isbuy) {
        this.isbuy = isbuy == null ? null : isbuy.trim();
    }

    public String getOilunit() {
        return oilunit;
    }

    public void setOilunit(String oilunit) {
        this.oilunit = oilunit == null ? null : oilunit.trim();
    }

    public String getOilcycle() {
        return oilcycle;
    }

    public void setOilcycle(String oilcycle) {
        this.oilcycle = oilcycle == null ? null : oilcycle.trim();
    }

    public String getCheckcycle() {
        return checkcycle;
    }

    public void setCheckcycle(String checkcycle) {
        this.checkcycle = checkcycle == null ? null : checkcycle.trim();
    }

    public Date getOilnext() {
        return oilnext;
    }

    public void setOilnext(Date oilnext) {
        this.oilnext = oilnext;
    }

    public Date getChecknext() {
        return checknext;
    }

    public void setChecknext(Date checknext) {
        this.checknext = checknext;
    }

    public Date getFixdate() {
        return fixdate;
    }

    public void setFixdate(Date fixdate) {
        this.fixdate = fixdate;
    }

    public Date getRemovedate() {
        return removedate;
    }

    public void setRemovedate(Date removedate) {
        this.removedate = removedate;
    }

    public String getMeterbox() {
        return meterbox;
    }

    public void setMeterbox(String meterbox) {
        this.meterbox = meterbox == null ? null : meterbox.trim();
    }

    public String getPosinum() {
        return posinum;
    }

    public void setPosinum(String posinum) {
        this.posinum = posinum == null ? null : posinum.trim();
    }

    public String getFixmode() {
        return fixmode;
    }

    public void setFixmode(String fixmode) {
        this.fixmode = fixmode == null ? null : fixmode.trim();
    }

    public String getMeterposi() {
        return meterposi;
    }

    public void setMeterposi(String meterposi) {
        this.meterposi = meterposi == null ? null : meterposi.trim();
    }

    public String getCarddirect() {
        return carddirect;
    }

    public void setCarddirect(String carddirect) {
        this.carddirect = carddirect == null ? null : carddirect.trim();
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env == null ? null : env.trim();
    }

    public String getIssafety() {
        return issafety;
    }

    public void setIssafety(String issafety) {
        this.issafety = issafety == null ? null : issafety.trim();
    }

    public BigDecimal getTemppressfactor() {
        return temppressfactor;
    }

    public void setTemppressfactor(BigDecimal temppressfactor) {
        this.temppressfactor = temppressfactor;
    }

    public BigDecimal getAdjustfactor() {
        return adjustfactor;
    }

    public void setAdjustfactor(BigDecimal adjustfactor) {
        this.adjustfactor = adjustfactor;
    }

    public String getImgcode() {
        return imgcode;
    }

    public void setImgcode(String imgcode) {
        this.imgcode = imgcode == null ? null : imgcode.trim();
    }

    public String getSealcode() {
        return sealcode;
    }

    public void setSealcode(String sealcode) {
        this.sealcode = sealcode == null ? null : sealcode.trim();
    }

    public String getModifiercode() {
        return modifiercode;
    }

    public void setModifiercode(String modifiercode) {
        this.modifiercode = modifiercode == null ? null : modifiercode.trim();
    }

    public BigDecimal getBasefactor() {
        return basefactor;
    }

    public void setBasefactor(BigDecimal basefactor) {
        this.basefactor = basefactor;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public Long getVer() {
        return ver;
    }

    public void setVer(Long ver) {
        this.ver = ver;
    }

    public String getNewflag() {
        return newflag;
    }

    public void setNewflag(String newflag) {
        this.newflag = newflag == null ? null : newflag.trim();
    }

    public String getAreapart() {
        return areapart;
    }

    public void setAreapart(String areapart) {
        this.areapart = areapart == null ? null : areapart.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand == null ? null : stand.trim();
    }
}