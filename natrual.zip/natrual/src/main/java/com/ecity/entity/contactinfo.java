package com.ecity.entity;

import java.util.Date;

public class contactinfo {
    private String busisn;

    private String busitype;

    private String nodesn;

    private String nodetype;

    private String contactid;

    private String owntype;

    private String ownid;

    private String type;

    private String name;

    private String position;

    private String deptname;

    private String contactphone;

    private String mobile;

    private String contactaddr;

    private String zipcode;

    private String birthday;

    private String fax;

    private String email;

    private Long ver;

    private String newflag;

    private String areapart;

    private String optrcode;

    private Date optdate;

    private String remark;

    private String stand;

    public String getBusisn() {
        return busisn;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getBusitype() {
        return busitype;
    }

    public void setBusitype(String busitype) {
        this.busitype = busitype == null ? null : busitype.trim();
    }

    public String getNodesn() {
        return nodesn;
    }

    public void setNodesn(String nodesn) {
        this.nodesn = nodesn == null ? null : nodesn.trim();
    }

    public String getNodetype() {
        return nodetype;
    }

    public void setNodetype(String nodetype) {
        this.nodetype = nodetype == null ? null : nodetype.trim();
    }

    public String getContactid() {
        return contactid;
    }

    public void setContactid(String contactid) {
        this.contactid = contactid == null ? null : contactid.trim();
    }

    public String getOwntype() {
        return owntype;
    }

    public void setOwntype(String owntype) {
        this.owntype = owntype == null ? null : owntype.trim();
    }

    public String getOwnid() {
        return ownid;
    }

    public void setOwnid(String ownid) {
        this.ownid = ownid == null ? null : ownid.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position == null ? null : position.trim();
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname == null ? null : deptname.trim();
    }

    public String getContactphone() {
        return contactphone;
    }

    public void setContactphone(String contactphone) {
        this.contactphone = contactphone == null ? null : contactphone.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getContactaddr() {
        return contactaddr;
    }

    public void setContactaddr(String contactaddr) {
        this.contactaddr = contactaddr == null ? null : contactaddr.trim();
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode == null ? null : zipcode.trim();
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday == null ? null : birthday.trim();
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax == null ? null : fax.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public Long getVer() {
        return ver;
    }

    public void setVer(Long ver) {
        this.ver = ver;
    }

    public String getNewflag() {
        return newflag;
    }

    public void setNewflag(String newflag) {
        this.newflag = newflag == null ? null : newflag.trim();
    }

    public String getAreapart() {
        return areapart;
    }

    public void setAreapart(String areapart) {
        this.areapart = areapart == null ? null : areapart.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand == null ? null : stand.trim();
    }
}