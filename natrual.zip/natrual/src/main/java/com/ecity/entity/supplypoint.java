package com.ecity.entity;

import java.math.BigDecimal;
import java.util.Date;

public class supplypoint {
    private String busisn;

    private String projectid;

    private String supplypointid;

    private String riserid;

    private String risertype;

    private String stationid;

    private String sourcetype;

    private BigDecimal pressfactor;

    private String presslvl;

    private String addrcode;

    private String addrdetail;

    private String state;

    private String mngorg;

    private String lastbusisn;

    private String optrcode;

    private Date optdate;

    private String remark;

    private String stand;

    public String getBusisn() {
        return busisn;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getSupplypointid() {
        return supplypointid;
    }

    public void setSupplypointid(String supplypointid) {
        this.supplypointid = supplypointid == null ? null : supplypointid.trim();
    }

    public String getRiserid() {
        return riserid;
    }

    public void setRiserid(String riserid) {
        this.riserid = riserid == null ? null : riserid.trim();
    }

    public String getRisertype() {
        return risertype;
    }

    public void setRisertype(String risertype) {
        this.risertype = risertype == null ? null : risertype.trim();
    }

    public String getStationid() {
        return stationid;
    }

    public void setStationid(String stationid) {
        this.stationid = stationid == null ? null : stationid.trim();
    }

    public String getSourcetype() {
        return sourcetype;
    }

    public void setSourcetype(String sourcetype) {
        this.sourcetype = sourcetype == null ? null : sourcetype.trim();
    }

    public BigDecimal getPressfactor() {
        return pressfactor;
    }

    public void setPressfactor(BigDecimal pressfactor) {
        this.pressfactor = pressfactor;
    }

    public String getPresslvl() {
        return presslvl;
    }

    public void setPresslvl(String presslvl) {
        this.presslvl = presslvl == null ? null : presslvl.trim();
    }

    public String getAddrcode() {
        return addrcode;
    }

    public void setAddrcode(String addrcode) {
        this.addrcode = addrcode == null ? null : addrcode.trim();
    }

    public String getAddrdetail() {
        return addrdetail;
    }

    public void setAddrdetail(String addrdetail) {
        this.addrdetail = addrdetail == null ? null : addrdetail.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getMngorg() {
        return mngorg;
    }

    public void setMngorg(String mngorg) {
        this.mngorg = mngorg == null ? null : mngorg.trim();
    }

    public String getLastbusisn() {
        return lastbusisn;
    }

    public void setLastbusisn(String lastbusisn) {
        this.lastbusisn = lastbusisn == null ? null : lastbusisn.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand == null ? null : stand.trim();
    }
}