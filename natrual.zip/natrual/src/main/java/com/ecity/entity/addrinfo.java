package com.ecity.entity;

import java.util.Date;

public class addrinfo {
    private String addrid;

    private String busisn;

    private String fulname;

    private String lvlname;

    private String addrlvl;

    private String parentaddr;

    private String orgcode;

    private String state;

    private String lastbusisn;

    private String optrcode;

    private Date optdate;

    public String getAddrid() {
        return addrid;
    }

    public void setAddrid(String addrid) {
        this.addrid = addrid == null ? null : addrid.trim();
    }

    public String getBusisn() {
        return busisn;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getFulname() {
        return fulname;
    }

    public void setFulname(String fulname) {
        this.fulname = fulname == null ? null : fulname.trim();
    }

    public String getLvlname() {
        return lvlname;
    }

    public void setLvlname(String lvlname) {
        this.lvlname = lvlname == null ? null : lvlname.trim();
    }

    public String getAddrlvl() {
        return addrlvl;
    }

    public void setAddrlvl(String addrlvl) {
        this.addrlvl = addrlvl == null ? null : addrlvl.trim();
    }

    public String getParentaddr() {
        return parentaddr;
    }

    public void setParentaddr(String parentaddr) {
        this.parentaddr = parentaddr == null ? null : parentaddr.trim();
    }

    public String getOrgcode() {
        return orgcode;
    }

    public void setOrgcode(String orgcode) {
        this.orgcode = orgcode == null ? null : orgcode.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getLastbusisn() {
        return lastbusisn;
    }

    public void setLastbusisn(String lastbusisn) {
        this.lastbusisn = lastbusisn == null ? null : lastbusisn.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }
}