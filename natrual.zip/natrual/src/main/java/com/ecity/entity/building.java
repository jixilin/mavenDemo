package com.ecity.entity;

import java.math.BigDecimal;
import java.util.Date;

public class building {
    private String buildingid;

    private String buildingname;

    private String stationid;

    private String addrcode;

    private BigDecimal unitnum;

    private BigDecimal floornum;

    private BigDecimal usernum;

    private String state;

    private String lastbusisn;

    private String optrcode;

    private Date optdate;

    private String remark;

    private String stand;

    public String getBuildingid() {
        return buildingid;
    }

    public void setBuildingid(String buildingid) {
        this.buildingid = buildingid == null ? null : buildingid.trim();
    }

    public String getBuildingname() {
        return buildingname;
    }

    public void setBuildingname(String buildingname) {
        this.buildingname = buildingname == null ? null : buildingname.trim();
    }

    public String getStationid() {
        return stationid;
    }

    public void setStationid(String stationid) {
        this.stationid = stationid == null ? null : stationid.trim();
    }

    public String getAddrcode() {
        return addrcode;
    }

    public void setAddrcode(String addrcode) {
        this.addrcode = addrcode == null ? null : addrcode.trim();
    }

    public BigDecimal getUnitnum() {
        return unitnum;
    }

    public void setUnitnum(BigDecimal unitnum) {
        this.unitnum = unitnum;
    }

    public BigDecimal getFloornum() {
        return floornum;
    }

    public void setFloornum(BigDecimal floornum) {
        this.floornum = floornum;
    }

    public BigDecimal getUsernum() {
        return usernum;
    }

    public void setUsernum(BigDecimal usernum) {
        this.usernum = usernum;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getLastbusisn() {
        return lastbusisn;
    }

    public void setLastbusisn(String lastbusisn) {
        this.lastbusisn = lastbusisn == null ? null : lastbusisn.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand == null ? null : stand.trim();
    }
}