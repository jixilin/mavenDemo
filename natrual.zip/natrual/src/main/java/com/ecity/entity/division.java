package com.ecity.entity;

import java.util.Date;
import java.util.List;

public class division {
    private String busisn;

    private String busisnhis;

    private String orgcode;

    private String divid;

    private String divname;

    private String parentdivid;

    private String state;

    private String optrcode;

    private Date optdate;

    private String remark;

    private String stand;

    private String areatype;

    private List<division> children;


    public String getBusisn() {
        return busisn;
    }

    public List<division> getChildren() {
        return children;
    }

    public void setChildren(List<division> children) {
        this.children = children;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getBusisnhis() {
        return busisnhis;
    }

    public void setBusisnhis(String busisnhis) {
        this.busisnhis = busisnhis == null ? null : busisnhis.trim();
    }

    public String getOrgcode() {
        return orgcode;
    }

    public void setOrgcode(String orgcode) {
        this.orgcode = orgcode == null ? null : orgcode.trim();
    }

    public String getDivid() {
        return divid;
    }

    public void setDivid(String divid) {
        this.divid = divid == null ? null : divid.trim();
    }

    public String getDivname() {
        return divname;
    }

    public void setDivname(String divname) {
        this.divname = divname == null ? null : divname.trim();
    }

    public String getParentdivid() {
        return parentdivid;
    }

    public void setParentdivid(String parentdivid) {
        this.parentdivid = parentdivid == null ? null : parentdivid.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand == null ? null : stand.trim();
    }

    public String getAreatype() {
        return areatype;
    }

    public void setAreatype(String areatype) {
        this.areatype = areatype == null ? null : areatype.trim();
    }
}