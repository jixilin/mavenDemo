package com.ecity.entity;

import java.math.BigDecimal;
import java.util.Date;

public class userinfo {
    private String userid;

    private String busisn;

    private String busitype;

    private String nodesn;

    private String nodetype;

    private String username;

    private String custid;

    private String svctype;

    private String usertype;

    private String consumptype;

    private String consumpattr;

    private String userstate;

    private String addrcode;

    private String addrdetail;

    private Date statechngdate;

    private String industrytype;

    private String consumpdesc;

    private Date aeratedate;

    private BigDecimal housearea;

    private Integer usersnum;

    private String latefeeflag;

    private String mngorg;

    private String stenocode;

    private String stenoprompt;

    private String stenopassword;

    private Integer credit;

    private String archcode;

    private String chnltype;

    private String chnlid;

    private Long ver;

    private String newflag;

    private String areapart;

    private String optrcode;

    private Date optdate;

    private String remark;

    private String stand;

    private String userlvl;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getBusisn() {
        return busisn;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getBusitype() {
        return busitype;
    }

    public void setBusitype(String busitype) {
        this.busitype = busitype == null ? null : busitype.trim();
    }

    public String getNodesn() {
        return nodesn;
    }

    public void setNodesn(String nodesn) {
        this.nodesn = nodesn == null ? null : nodesn.trim();
    }

    public String getNodetype() {
        return nodetype;
    }

    public void setNodetype(String nodetype) {
        this.nodetype = nodetype == null ? null : nodetype.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getCustid() {
        return custid;
    }

    public void setCustid(String custid) {
        this.custid = custid == null ? null : custid.trim();
    }

    public String getSvctype() {
        return svctype;
    }

    public void setSvctype(String svctype) {
        this.svctype = svctype == null ? null : svctype.trim();
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype == null ? null : usertype.trim();
    }

    public String getConsumptype() {
        return consumptype;
    }

    public void setConsumptype(String consumptype) {
        this.consumptype = consumptype == null ? null : consumptype.trim();
    }

    public String getConsumpattr() {
        return consumpattr;
    }

    public void setConsumpattr(String consumpattr) {
        this.consumpattr = consumpattr == null ? null : consumpattr.trim();
    }

    public String getUserstate() {
        return userstate;
    }

    public void setUserstate(String userstate) {
        this.userstate = userstate == null ? null : userstate.trim();
    }

    public String getAddrcode() {
        return addrcode;
    }

    public void setAddrcode(String addrcode) {
        this.addrcode = addrcode == null ? null : addrcode.trim();
    }

    public String getAddrdetail() {
        return addrdetail;
    }

    public void setAddrdetail(String addrdetail) {
        this.addrdetail = addrdetail == null ? null : addrdetail.trim();
    }

    public Date getStatechngdate() {
        return statechngdate;
    }

    public void setStatechngdate(Date statechngdate) {
        this.statechngdate = statechngdate;
    }

    public String getIndustrytype() {
        return industrytype;
    }

    public void setIndustrytype(String industrytype) {
        this.industrytype = industrytype == null ? null : industrytype.trim();
    }

    public String getConsumpdesc() {
        return consumpdesc;
    }

    public void setConsumpdesc(String consumpdesc) {
        this.consumpdesc = consumpdesc == null ? null : consumpdesc.trim();
    }

    public Date getAeratedate() {
        return aeratedate;
    }

    public void setAeratedate(Date aeratedate) {
        this.aeratedate = aeratedate;
    }

    public BigDecimal getHousearea() {
        return housearea;
    }

    public void setHousearea(BigDecimal housearea) {
        this.housearea = housearea;
    }

    public Integer getUsersnum() {
        return usersnum;
    }

    public void setUsersnum(Integer usersnum) {
        this.usersnum = usersnum;
    }

    public String getLatefeeflag() {
        return latefeeflag;
    }

    public void setLatefeeflag(String latefeeflag) {
        this.latefeeflag = latefeeflag == null ? null : latefeeflag.trim();
    }

    public String getMngorg() {
        return mngorg;
    }

    public void setMngorg(String mngorg) {
        this.mngorg = mngorg == null ? null : mngorg.trim();
    }

    public String getStenocode() {
        return stenocode;
    }

    public void setStenocode(String stenocode) {
        this.stenocode = stenocode == null ? null : stenocode.trim();
    }

    public String getStenoprompt() {
        return stenoprompt;
    }

    public void setStenoprompt(String stenoprompt) {
        this.stenoprompt = stenoprompt == null ? null : stenoprompt.trim();
    }

    public String getStenopassword() {
        return stenopassword;
    }

    public void setStenopassword(String stenopassword) {
        this.stenopassword = stenopassword == null ? null : stenopassword.trim();
    }

    public Integer getCredit() {
        return credit;
    }

    public void setCredit(Integer credit) {
        this.credit = credit;
    }

    public String getArchcode() {
        return archcode;
    }

    public void setArchcode(String archcode) {
        this.archcode = archcode == null ? null : archcode.trim();
    }

    public String getChnltype() {
        return chnltype;
    }

    public void setChnltype(String chnltype) {
        this.chnltype = chnltype == null ? null : chnltype.trim();
    }

    public String getChnlid() {
        return chnlid;
    }

    public void setChnlid(String chnlid) {
        this.chnlid = chnlid == null ? null : chnlid.trim();
    }

    public Long getVer() {
        return ver;
    }

    public void setVer(Long ver) {
        this.ver = ver;
    }

    public String getNewflag() {
        return newflag;
    }

    public void setNewflag(String newflag) {
        this.newflag = newflag == null ? null : newflag.trim();
    }

    public String getAreapart() {
        return areapart;
    }

    public void setAreapart(String areapart) {
        this.areapart = areapart == null ? null : areapart.trim();
    }

    public String getOptrcode() {
        return optrcode;
    }

    public void setOptrcode(String optrcode) {
        this.optrcode = optrcode == null ? null : optrcode.trim();
    }

    public Date getOptdate() {
        return optdate;
    }

    public void setOptdate(Date optdate) {
        this.optdate = optdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand == null ? null : stand.trim();
    }

    public String getUserlvl() {
        return userlvl;
    }

    public void setUserlvl(String userlvl) {
        this.userlvl = userlvl == null ? null : userlvl.trim();
    }
}