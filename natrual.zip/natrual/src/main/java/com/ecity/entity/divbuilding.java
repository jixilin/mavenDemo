package com.ecity.entity;

public class divbuilding {
    private String busisn;

    private String divid;

    private String buildingid;

    private String state;

    private String batchid;

    private String oldbusisn;

    public String getBusisn() {
        return busisn;
    }

    public void setBusisn(String busisn) {
        this.busisn = busisn == null ? null : busisn.trim();
    }

    public String getDivid() {
        return divid;
    }

    public void setDivid(String divid) {
        this.divid = divid == null ? null : divid.trim();
    }

    public String getBuildingid() {
        return buildingid;
    }

    public void setBuildingid(String buildingid) {
        this.buildingid = buildingid == null ? null : buildingid.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getBatchid() {
        return batchid;
    }

    public void setBatchid(String batchid) {
        this.batchid = batchid == null ? null : batchid.trim();
    }

    public String getOldbusisn() {
        return oldbusisn;
    }

    public void setOldbusisn(String oldbusisn) {
        this.oldbusisn = oldbusisn == null ? null : oldbusisn.trim();
    }
}