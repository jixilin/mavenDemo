package com.ecity.utils;

import com.ecity.bean.DataResponse;

import java.util.List;

public class ResponseUtil {

    public static DataResponse response(Integer code) {
        return new DataResponse(code);
    }

    public static DataResponse response(Integer code, String message) {
        return new DataResponse(code, message);
    }
    public static DataResponse response(Integer code, String message,List<?> object) {
        return new DataResponse(code, message,object);
    }
}
