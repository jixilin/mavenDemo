package com.ecity.utils;

import com.ecity.entity.division;
import net.sf.jsqlparser.expression.operators.arithmetic.Division;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

import javax.servlet.http.HttpServletRequest;


public  class CommonUtil {

    /**
     * 从request中获得参数Map，并返回可读的Map.
     *
     * @param request the request
     * @return the parameter map
     */
    public static Map<String, Object> getParameterMap(HttpServletRequest request) {
        // 参数Map
        Map<String, String[]> properties = request.getParameterMap();
        //返回值Map
        Map<String, Object> returnMap = new HashMap<String, Object>();
        Set<String> keySet = properties.keySet();
        for(String key: keySet){
            String[] values = properties.get(key);
            String value = "";
            if(values != null && (values.length==1&& StringUtils.isNotBlank(values[0]))?true:false){
                for(int i=0;i<values.length;i++){
                    if(values[i] != null && !"".equals(values[i])){
//							value = new String(values[i].getBytes("ISO-8859-1"),"UTF-8") + ",";
                        value += values[i] + ",";
                    }
                }
                if(value != null && !"".equals(value)){
                    value = value.substring(0, value.length()-1);
                }
                if(key.equals("keywords")){//关键字特殊查询字符转义
                    value =  value.replace("_", "\\_").replace("%", "\\%");
                }
                returnMap.put(key, value);
            }
        }
        return returnMap;
    }
    /**
     * **/
    public static  List<division> useListRecordToTree(List<division> allRrecords) {

        List<division> listParentRecord = new ArrayList<division>();
        List<division> listNotParentRecord = new ArrayList<division>();
        Map<String, String> mapAllid = new HashMap<String, String>();
        Map<String, division> allRecordMap = new HashMap<String, division>();
        for (division record : allRrecords) {
            mapAllid.put(record.getDivid(),record.getDivid());
            allRecordMap.put(record.getDivid(), record);
        }
        if (allRrecords != null && allRrecords.size() > 0) {
            for (division record : allRrecords) {
                if (StringUtils.isBlank(record.getParentdivid())
                        || !mapAllid.containsKey(record.getParentdivid())) {
                    listParentRecord.add(record);
                } else {
                    listNotParentRecord.add(record);
                }
            }
        }
        if (listParentRecord.size() > 0) {
            for (division records : listParentRecord) {
                // 添加所有子级
                List<division> children = getTreeChildRecord(listNotParentRecord, records.getDivid());
                if(children != null && children.size() != 0)
                records.setChildren(children);
            }
        }
        return listParentRecord;
    }

    private static  List<division> getTreeChildRecord(List<division> childList, String parentid) {

        List<division> listParentRecord = new ArrayList<division>();
        List<division> listNotParentRecord = new ArrayList<division>();
        if (childList != null && childList.size() > 0) {
            for (division record : childList) {
                if (StringUtils.equals(record.getParentdivid(), parentid)) {
                    listParentRecord.add(record);
                } else {
                    listNotParentRecord.add(record);
                }
            }
        }
        if (listParentRecord.size() > 0) {
            for (division record : listParentRecord) {
                List<division> children = getTreeChildRecord(listNotParentRecord, record.getDivid());
                if(children != null && children.size() != 0)
                record.setChildren(children);
                System.out.println("不要你的下划线");
            }
        }
        return listParentRecord;
    }


}
