package com.ecity.utils.redis.cluster;

public class ClusterConfigurationProperties {

}
