package com.ecity.service.Impl;

import com.ecity.dao.userinfoMapper;
import com.ecity.entity.userinfo;
import com.ecity.exception.ecityException;
import com.ecity.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserserviceImpl implements  Userservice {

    @Autowired
    userinfoMapper userinfoMapper;


    @Transactional(rollbackFor = ecityException.class)
    @Override
    public void upflag(String newflag, String userid) {
        userinfo user = new userinfo();
        user.setNewflag(newflag);user.setUserid(userid);
        userinfoMapper.updateByPrimaryKeySelective(user);
    }
}
