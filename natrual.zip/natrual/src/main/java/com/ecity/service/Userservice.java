package com.ecity.service;

/**
 * Created by Administrator on 2017/6/28.
 */
public interface Userservice {

     void upflag(String newflag,String userid);
}
