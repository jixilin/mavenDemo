package com.ecity.service.Impl;

import com.ecity.dao.buildingMapper;
import com.ecity.dao.buildinggeoMapper;
import com.ecity.dao.divisionMapper;
import com.ecity.entity.buildinggeo;
import com.ecity.entity.division;
import com.ecity.service.Naservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/6/15.
 */
@Service
public class NaserviceImpl implements Naservice {

    @Autowired
    private buildinggeoMapper buildinggeoMapper;
    @Autowired
    private divisionMapper divisionMapper;
    @Autowired
    protected buildingMapper buildingMapper;

    public List<buildinggeo> getList(String state,String geoid) {
        return buildinggeoMapper.selectAllBind(state,geoid);
    }

    @Override
    @Cacheable(value = "index",keyGenerator = "wiselyKeyGenerator")
    public List<division> index() {
        return divisionMapper.index();
    }

    @Override
    @Cacheable(value = "getdetail",keyGenerator = "wiselyKeyGenerator")
    public List<Map> getdetail(String divid) {
        return buildingMapper.getdetail(divid);
    }

}
