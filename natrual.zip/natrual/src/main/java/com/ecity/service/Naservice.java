package com.ecity.service;


import com.ecity.entity.buildinggeo;
import com.ecity.entity.division;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/6/15.
 */
public  interface Naservice {

     List<buildinggeo> getList(String state, String geoid);
     List<division> index();
     List<Map> getdetail(String divid);
}
