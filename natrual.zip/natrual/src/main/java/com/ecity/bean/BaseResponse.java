package com.ecity.bean;


public class BaseResponse {

	private Integer code;

	private String message;

	public BaseResponse() {
		
	}

     public BaseResponse(String message) {
    	 this.setMessage(message);
	}

	public BaseResponse(Integer code) {
		this.code = code;
	}

	public BaseResponse(Integer code, boolean success) {
		this.code = code;
	}
	public BaseResponse(Integer code, String message) {
		this.code = code;
		this.setMessage(message);
	}
	

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}