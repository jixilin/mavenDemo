package com.ecity.bean;

public class Code   {

    /**
     * 成功
     */
    public static final int SUCCESS = 0;

    /**
     * 失败 
     */
    public static final int FAIL = 1001;

    /**
     * 参数错误: 缺少或参数值不符合要求
     */
    public static final int ARGUMENT_ERROR = 1002;

}
