package com.ecity.controller;

import com.ecity.bean.Code;
import com.ecity.bean.DataResponse;
import com.ecity.common.StringPool;
import com.ecity.entity.buildinggeo;
import com.ecity.entity.division;
import com.ecity.service.Naservice;
import com.ecity.utils.ResponseUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

import static com.ecity.utils.CommonUtil.useListRecordToTree;


/**
 * Created by Administrator on 2017/6/15.
 */
@RestController
@RequestMapping(value = "/api/floor")
public class NaApiController {

    @Autowired
    Naservice naservice;
    public static final Logger logger = Logger.getLogger(NaApiController.class);

    /**
     * 获取所有已绑定的覆盖物信息
     * @param
     * @param
     * @return
     */
    @RequestMapping(value = "/allbind",method = RequestMethod.GET)
    public ResponseEntity<Object> allbind(@RequestParam String state,@RequestParam(required=false) String geoid){

        List<buildinggeo>  geo = naservice.getList(state,geoid);



        DataResponse response = new DataResponse();
        response.setCode(Code.SUCCESS);
        response.setMessage(StringPool.SUCESS);
        response.setData(geo);
        logger.info(response.getMessage());
        return  new ResponseEntity<Object>(response,HttpStatus.OK);

    }

    /**
     * 获取栋与楼层、用户之间相关信息
     * @param
     * @return
     * select * from T_SS_DIVISION t start with t.Parentdivid = '0' connect by prior t.divid = t.Parentdivid
     * */
    @RequestMapping(value = "",method = RequestMethod.GET)
    public DataResponse index(){

        //查询片区与楼栋数据
        List<division> listMeterUseInfo = naservice.index();
        List<division> divlist = useListRecordToTree(listMeterUseInfo);
        logger.info(StringPool.SUCESS);
        return ResponseUtil.response(Code.SUCCESS,StringPool.SUCESS,divlist);
    }

    /**
     *获取小区里的所有房屋
     *@return  state为null则未绑定，0：绑定 1：已解绑（可理解为未绑定）
     */
    @RequestMapping(value = "/getdetail",method = RequestMethod.GET)
    public DataResponse getdetail(@RequestParam String divid)
    {

        return ResponseUtil.response(Code.SUCCESS,StringPool.SUCESS,naservice.getdetail(divid));

    }
}
