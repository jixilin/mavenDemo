package com.ecity.controller;

import com.ecity.bean.BaseResponse;
import com.ecity.bean.Code;
import com.ecity.common.StringPool;
import com.ecity.service.Userservice;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Administrator on 2017/6/28.
 */
@RestController
@RequestMapping(value = "/api/user")
public class UserApiController {

    @Autowired
    private Userservice userservice;
    public static final Logger logger = Logger.getLogger(NaApiController.class);


    @RequestMapping(value = "/upflag",method = RequestMethod.GET)
    public ResponseEntity<Object> upflag(@RequestParam String newflag, @RequestParam String ids) throws Exception {

        String id = ids;
        String[] idarr = id.split("\\,");
        if(idarr.length == 0) return new ResponseEntity<Object>(new BaseResponse(Code.ARGUMENT_ERROR,StringPool.ARGUMENT_ERROR), HttpStatus.OK);

        for(String userid:idarr) {
            userservice.upflag(newflag, userid);
          //  throw new Exception();
        }

        return new ResponseEntity<Object>(new BaseResponse(Code.SUCCESS,StringPool.SUCESS), HttpStatus.OK);
        }

}
