
package com.ecity.common;

public interface StringPool {
	
	final String ARGUMENT_ERROR = "参数错误";
	final String SERVER_ERROR = "服务器内部出现错误";
	final String SUCESS = "SUCESS";
	final String GEO_FAIL = "附属物绑定/解绑失败";
	final String BING_FAIL = "附属物已绑定";
	final String NO_BING= "解绑之前请绑定/已经解绑";
	final String NO_BAND= "已经绑定的不是当前建筑物ID";
}
